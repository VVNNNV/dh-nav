<?php
/**
 * 大海导航 - Custom Post Types and Taxonomies
 *
 * @package AI_Navigator_Hub
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * 注册自定义文章类型
 */
function ai_navigator_register_post_types() {
    register_post_type( 'ai_tool', array(
        'labels' => array(
            'name' => __('网站', 'dh-nav'),
            'singular_name' => __('网站', 'dh-nav'),
            'menu_name' => __('网站', 'dh-nav'),
            'add_new' => __('添加网站', 'dh-nav'),
            'add_new_item' => __('添加新网站', 'dh-nav'),
            'edit_item' => __('编辑网站', 'dh-nav'),
            'new_item' => __('新网站', 'dh-nav'),
            'view_item' => __('查看网站', 'dh-nav'),
            'all_items' => __('所有网站', 'dh-nav'),
            'search_items' => __('搜索网站', 'dh-nav'),
            'not_found' => __('未找到网站', 'dh-nav'),
        ),
        'public' => true,
        'show_in_rest' => true,
        'rest_base' => 'ai_tool',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
        'has_archive' => false,
        'rewrite' => array('slug' => 'site'),
        'show_ui' => true,
        'show_in_menu' => false,
        'menu_icon' => 'dashicons-admin-tools',
    ));

    register_taxonomy('ai_category', 'ai_tool', array(
        'labels' => array('name' => __('网站分类', 'dh-nav'), 'singular_name' => __('网站分类', 'dh-nav')),
        'hierarchical' => true,
        'show_ui' => true,
        'show_admin_column' => true,
        'show_in_nav_menus' => true,
        'query_var' => true,
        'show_in_rest' => true,
        'rest_base' => 'ai_category',
        'rewrite' => array('slug' => 'site-category'),
        'show_admin_filter' => true,
    ));

    register_taxonomy('ai_tag', 'ai_tool', array(
        'labels' => array('name' => __('网站标签', 'dh-nav'), 'singular_name' => __('网站标签', 'dh-nav')),
        'hierarchical' => false,
        'show_ui' => true,
        'show_admin_column' => true,
        'show_in_nav_menus' => true,
        'query_var' => true,
        'show_in_rest' => true,
        'rest_base' => 'ai_tag',
        'rewrite' => array('slug' => 'site-tag'),
    ));
}
add_action('init', 'ai_navigator_register_post_types');

/**
 * 自定义 ai_tool 文章类型的固定链接格式为 /site/{post_id}.html
 */
function ai_navigator_custom_post_type_link($post_link, $post) {
    if ($post->post_type === 'ai_tool') {
        return home_url('/site/' . $post->ID . '.html');
    }
    return $post_link;
}
add_filter('post_type_link', 'ai_navigator_custom_post_type_link', 10, 2);

/**
 * 添加 ai_tool 的自定义重写规则，支持 /site/{id}.html 格式
 */
function ai_navigator_add_custom_rewrite_rules() {
    add_rewrite_rule('^site/([0-9]+)\.html$', 'index.php?post_type=ai_tool&p=$matches[1]', 'top');
}
add_action('init', 'ai_navigator_add_custom_rewrite_rules');

/**
 * 注册元数据
 */
function ai_navigator_register_meta() {
    register_post_meta('ai_tool', 'tool_url', array('type' => 'string', 'single' => true, 'show_in_rest' => true, 'sanitize_callback' => 'esc_url'));
    register_post_meta('ai_tool', 'tool_icon', array('type' => 'string', 'single' => true, 'show_in_rest' => true));
    register_post_meta('ai_tool', 'tool_hot', array('type' => 'boolean', 'single' => true, 'show_in_rest' => true));
    register_post_meta('ai_tool', 'tool_order', array('type' => 'integer', 'single' => true, 'show_in_rest' => true));
}
add_action('init', 'ai_navigator_register_meta');

/**
 * REST API 响应添加字段
 */
function ai_navigator_rest_prepare_post($response, $post, $request) {
    if ($post->post_type === 'ai_tool') {
        $response->data['tool_url'] = get_post_meta($post->ID, 'tool_url', true);
        $response->data['tool_icon'] = get_post_meta($post->ID, 'tool_icon', true);
        $response->data['tool_hot'] = (bool)get_post_meta($post->ID, 'tool_hot', true);
        $response->data['tool_order'] = (int)get_post_meta($post->ID, 'tool_order', true);
        $categories = get_the_terms($post->ID, 'ai_category');
        $response->data['categories'] = $categories ? array_map(fn($t) => array('id' => $t->term_id, 'name' => $t->name, 'slug' => $t->slug), $categories) : array();
        $tags = get_the_terms($post->ID, 'ai_tag');
        $response->data['tags'] = $tags ? array_map(fn($t) => array('id' => $t->term_id, 'name' => $t->name, 'slug' => $t->slug), $tags) : array();
    }
    return $response;
}
add_filter('rest_prepare_ai_tool', 'ai_navigator_rest_prepare_post', 10, 3);

/**
 * 添加 Metabox
 */
function ai_navigator_add_meta_boxes() {
    add_meta_box('ai_tool_url_metabox', '网站信息', 'ai_navigator_tool_url_metabox_html', 'ai_tool', 'normal', 'high');
}
add_action('add_meta_boxes', 'ai_navigator_add_meta_boxes');

function ai_navigator_tool_url_metabox_html($post) {
    include get_template_directory() . '/includes/metabox-ui.php';
}

/**
 * 保存 Metabox 数据
 */
function ai_navigator_save_meta($post_id) {
    if (!isset($_POST['ai_navigator_meta_nonce']) || !wp_verify_nonce($_POST['ai_navigator_meta_nonce'], 'ai_navigator_save_meta')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    
    if (isset($_POST['tool_url'])) update_post_meta($post_id, 'tool_url', esc_url($_POST['tool_url']));
    if (isset($_POST['tool_icon'])) update_post_meta($post_id, 'tool_icon', sanitize_text_field($_POST['tool_icon']));
    update_post_meta($post_id, 'tool_hot', isset($_POST['tool_hot']) ? '1' : '');
    if (isset($_POST['tool_order'])) update_post_meta($post_id, 'tool_order', absint($_POST['tool_order']));
    
    $current_cats = wp_get_post_terms($post_id, 'ai_category', array('fields' => 'ids'));
    if (empty($current_cats) && isset($_POST['ai_default_category']) && $_POST['ai_default_category']) {
        wp_set_object_terms($post_id, absint($_POST['ai_default_category']), 'ai_category');
    }
    
    if (isset($_POST['ai_tags_input'])) {
        $tags = array_filter(array_map('trim', explode(',', $_POST['ai_tags_input'])));
        $tag_ids = array();
        foreach ($tags as $tag_name) {
            $tag = wp_insert_term($tag_name, 'ai_tag');
            if (!is_wp_error($tag)) {
                $tag_ids[] = $tag['term_id'];
            } else {
                $existing = get_term_by('name', $tag_name, 'ai_tag');
                if ($existing) $tag_ids[] = $existing->term_id;
            }
        }
        if (!empty($tag_ids)) wp_set_object_terms($post_id, $tag_ids, 'ai_tag');
    }
}
add_action('save_post_ai_tool', 'ai_navigator_save_meta');

/**
 * 注册自动获取 URL 信息的 API
 */
function ai_navigator_register_fetch_url_api() {
    register_rest_route('ai-navigator/v1', '/fetch-url', array(
        'methods' => 'GET',
        'callback' => 'ai_navigator_fetch_url_info',
        'permission_callback' => '__return_true',
    ));
}
add_action('rest_api_init', 'ai_navigator_register_fetch_url_api');

function ai_navigator_fetch_url_info($request) {
    $url = $request->get_param('url');
    if (empty($url)) return new WP_Error('empty_url', 'URL不能为空', array('status' => 400));
    if (!preg_match('/^https?:\/\//', $url)) $url = 'https://' . $url;
    
    $response = wp_remote_get($url, array('timeout' => 10, 'user-agent' => 'Mozilla/5.0'));
    if (is_wp_error($response)) return new WP_Error('fetch_error', '无法获取网页', array('status' => 500));
    
    $html = wp_remote_retrieve_body($response);
    if (empty($html)) return new WP_Error('empty_content', '网页内容为空', array('status' => 500));
    
    $title = '';
    if (preg_match('/<title[^>]*>([^<]*)<\/title>/i', $html, $matches)) {
        $title = trim($matches[1]);
        $title = preg_replace('/\s*[-|_]\s*[^-|_]+$/i', '', $title);
    }
    
    $description = '';
    if (preg_match('/<meta[^>]*name=["\']description["\'][^>]*content=["\']([^"\']*)["\'][^>]*>/i', $html, $matches)) {
        $description = trim($matches[1]);
    } elseif (preg_match('/<meta[^>]*content=["\']([^"\']*)["\'][^>]*name=["\']description["\'][^>]*>/i', $html, $matches)) {
        $description = trim($matches[1]);
    }
    
    $icon = ai_navigator_match_icon($title);
    $tags = ai_navigator_suggest_tags($title, $description);
    
    return array('title' => $title, 'description' => wp_strip_all_tags($description), 'icon' => $icon, 'tags' => $tags);
}

function ai_navigator_match_icon($name) {
    $name_lower = strtolower($name);
    $icon_map = array(
        'chatgpt' => '🤖', 'gpt' => '🤖', 'openai' => '🤖', 'claude' => '🧠', 'anthropic' => '🧠',
        'deepseek' => '🔍', 'midjourney' => '🎨', 'image' => '🎨', 'sora' => '🎬', 'video' => '🎬',
        'cursor' => '💻', 'code' => '💻', 'github' => '💻', 'perplexity' => '🔎', 'search' => '🔎',
        'bard' => '✨', 'gemini' => '✨', 'google' => '🔵', 'copilot' => '💡', 'microsoft' => '🔷',
        'notion' => '📝', 'canva' => '🖌️', 'jasper' => '✍️', 'write' => '✍️', 'eleven' => '🎵',
        'audio' => '🎵', 'voice' => '🎤', 'music' => '🎶', 'translate' => '🌐', 'pdf' => '📄',
        'spreadsheet' => '📊', 'presentation' => '📽️', 'ppt' => '📽️',
    );
    foreach ($icon_map as $keyword => $icon) {
        if (strpos($name_lower, $keyword) !== false) return $icon;
    }
    return '🔧';
}

function ai_navigator_suggest_tags($title, $description) {
    $text = strtolower($title . ' ' . $description);
    $tags = array();
    $keywords = array('conversation' => 'AI Conversation', 'chat' => 'AI Conversation', 'painting' => 'AI Art', 'image' => 'AI Art',
        'video' => 'AI Video', 'video' => 'AI Video', 'programming' => 'AI Coding', 'code' => 'AI Coding',
        'writing' => 'AI Writing', 'write' => 'AI Writing', 'search' => 'AI Search', 'search' => 'AI Search',
        'translation' => 'AI Translation', 'translate' => 'AI Translation', 'voice' => 'AI Voice', 'audio' => 'AI Audio',
        'ppt' => 'PPT', 'presentation' => 'PPT', 'document' => 'Document Processing', 'pdf' => 'PDF Processing');
    foreach ($keywords as $keyword => $tag) {
        if (strpos($text, $keyword) !== false && !in_array($tag, $tags)) $tags[] = $tag;
    }
    return array_slice($tags, 0, 5);
}

/**
 * Create Sample Data
 */
function ai_navigator_create_sample_data() {
    $existing = get_posts(array('post_type' => 'ai_tool', 'posts_per_page' => 1, 'post_status' => 'publish'));
    if (!empty($existing)) return;
    
    // Create Categories
    $categories = array(
        'llm' => 'Large Language Models',
        'proprietary' => 'Top Proprietary Models',
        'open_source' => 'All-Round Open Source Models',
        'image' => 'AI Art',
        'video' => 'AI Video',
        'audio' => 'AI Audio',
        '3d' => 'AI 3D / Modeling',
        'code' => 'AI Coding',
        'writing' => 'AI Writing',
        'search' => 'AI Search',
        'tool' => 'AI Websites',
        'community' => 'Model Communities',
        'productivity' => 'Office Productivity',
        'marketing' => 'E-commerce Marketing',
        'local' => 'Local Deployment',
    );
    
    $cat_ids = array();
    foreach ($categories as $slug => $name) {
        $term = get_term_by('slug', $slug, 'ai_category');
        if (!$term) {
            $result = wp_insert_term($name, 'ai_category', array('slug' => $slug));
            if (!is_wp_error($result)) {
                $cat_ids[$slug] = $result['term_id'];
            }
        } else {
            $cat_ids[$slug] = $term->term_id;
        }
    }
    
    // Sample Tool Data
    $sample_tools = array(
        // Large Language Models (LLM)
        array('title' => 'ChatGPT', 'description' => 'A powerful conversational AI developed by OpenAI, supporting multi-turn dialogue, code generation, content creation and various tasks.', 'url' => 'https://chat.openai.com', 'icon' => '🤖', 'category' => 'llm', 'tags' => array('AI Conversation', 'GPT-4', 'OpenAI'), 'hot' => true),
        array('title' => 'Claude', 'description' => 'A secure and reliable AI assistant built by Anthropic, specialized in long document analysis, coding assistance and advanced reasoning.', 'url' => 'https://claude.ai', 'icon' => '🧠', 'category' => 'llm', 'tags' => array('AI Conversation', 'Anthropic', 'Security'), 'hot' => true),
        array('title' => 'Gemini', 'description' => 'Google\'s multimodal AI model that supports text, image, audio and multiple input formats.', 'url' => 'https://gemini.google.com', 'icon' => '✨', 'category' => 'llm', 'tags' => array('Google', 'Multimodal'), 'hot' => true),
        array('title' => 'Doubao', 'description' => 'An intelligent AI assistant developed by ByteDance for daily Q&A, content creation, translation and general tasks.', 'url' => 'https://www.doubao.com', 'icon' => '🫘', 'category' => 'llm', 'tags' => array('ByteDance', 'Chinese AI'), 'hot' => true),
        array('title' => 'Kimi', 'description' => 'Ultra-long context AI assistant developed by Moonshot AI, supporting up to 200,000-word document processing.', 'url' => 'https://kimi.moonshot.cn', 'icon' => '🌙', 'category' => 'llm', 'tags' => array('Long Context', 'Moonshot AI')),
        array('title' => 'ERNIE', 'description' => 'Knowledge-enhanced large language model by Baidu, deeply integrated with search engines and knowledge graphs.', 'url' => 'https://yiyan.baidu.com', 'icon' => '📝', 'category' => 'llm', 'tags' => array('Baidu', 'Chinese AI')),
        array('title' => 'Tongyi Qwen', 'description' => 'Large language model from Alibaba Cloud with strong capabilities in dialogue, copywriting and logical reasoning.', 'url' => 'https://tongyi.aliyun.com', 'icon' => '🔮', 'category' => 'llm', 'tags' => array('Alibaba', 'Chinese AI')),
        array('title' => 'DeepSeek', 'description' => 'Open-source large model by DeepSeek AI, outstanding in code generation and mathematical reasoning.', 'url' => 'https://chat.deepseek.com', 'icon' => '🔍', 'category' => 'llm', 'tags' => array('Open Source', 'Coding', 'Reasoning'), 'hot' => true),
        array('title' => 'Meta Llama', 'description' => 'Open-source large language model series from Meta, widely used for research and commercial scenarios.', 'url' => 'https://llama.meta.com', 'icon' => '🦙', 'category' => 'llm', 'tags' => array('Meta', 'Open Source')),
        array('title' => 'Groq', 'description' => 'High-speed AI inference platform offering ultra-low latency LLM services.', 'url' => 'https://console.groq.com', 'icon' => '⚡', 'category' => 'llm', 'tags' => array('Inference', 'High Speed')),
        array('title' => 'Mistral', 'description' => 'Efficient open-source large model developed by a French AI startup, lightweight and easy to deploy.', 'url' => 'https://mistral.ai', 'icon' => '🌬️', 'category' => 'llm', 'tags' => array('Open Source', 'European AI')),
        array('title' => 'GLM', 'description' => 'Conversational large model by Zhipu AI with bilingual dialogue and knowledge Q&A capabilities.', 'url' => 'https://www.zhipuai.cn', 'icon' => '💎', 'category' => 'llm', 'tags' => array('Chinese AI', 'Tsinghua')),
        
        // Top Proprietary Models
        array('title' => 'GPT-5.4 Thinking', 'description' => 'OpenAI flagship model of 2026 with advanced thinking mode, reaching human expert level in complex logic reasoning and self-correction.', 'url' => 'https://chat.openai.com', 'icon' => '♾️', 'category' => 'proprietary', 'tags' => array('OpenAI', 'Advanced Reasoning', 'Multimodal'), 'hot' => true),
        array('title' => 'Claude Opus 4.7', 'description' => 'Released in April 2026 by Anthropic, currently ranked No.1 globally for code generation and dashboard building.', 'url' => 'https://claude.ai', 'icon' => '🎭', 'category' => 'proprietary', 'tags' => array('Anthropic', 'Superior Coding', 'Low Hallucination'), 'hot' => true),
        array('title' => 'Claude Mythos Preview', 'description' => 'Anthropic\'s highest-performance preview version, designed for large-scale scientific research and cross-domain complex tasks.', 'url' => 'https://claude.ai', 'icon' => '🔱', 'category' => 'proprietary', 'tags' => array('Ultra Large Model', 'Research-Grade')),
        array('title' => 'Gemini 3.5 Ultra', 'description' => 'Google native multimodal model, natively supporting hours-long video processing and million-line codebases with powerful ecosystem integration.', 'url' => 'https://gemini.google.com', 'icon' => '♊', 'category' => 'proprietary', 'tags' => array('Google', 'Native Multimodal', 'Ultra Long Context')),
        array('title' => 'Grok-3', 'description' => 'Developed by xAI, deeply integrated with real-time social data, featuring sharp tones and outstanding performance in math & physics competitions.', 'url' => 'https://x.ai', 'icon' => '🐦', 'category' => 'proprietary', 'tags' => array('xAI', 'Real-Time Data', 'Hardcore Science')),

        // All-Round Open Source Models
        array('title' => 'Llama 4 Maverick', 'description' => 'Meta flagship MoE open-source model released in 2025 with 400B+ parameters, fully comparable to GPT-4.5.', 'url' => 'https://llama.com', 'icon' => '🦙', 'category' => 'open_source', 'tags' => array('Meta', 'Open Source', 'MoE Architecture'), 'hot' => true),
        array('title' => 'Muse Spark', 'description' => 'Successor of the Llama series released by Meta Superintelligence Labs in April 2026, built for early AGI scenarios.', 'url' => 'https://github.com/meta-llama', 'icon' => '⚡', 'category' => 'open_source', 'tags' => array('AGI', 'Next-Gen Open Source')),
        array('title' => 'DeepSeek V4', 'description' => 'Released in February 2026 with self-developed Engram memory architecture, 1 million token context window and superior coding performance.', 'url' => 'https://chat.deepseek.com', 'icon' => '🔍', 'category' => 'open_source', 'tags' => array('Domestic Open Source', 'Engram Memory', 'King of Code'), 'hot' => true),
        array('title' => 'Qwen 3.6-Max', 'description' => 'Latest Alibaba MoE open-source model (April 2026), strong in Chinese comprehension and intelligent Agent orchestration.', 'url' => 'https://qwen.ai', 'icon' => '🔮', 'category' => 'open_source', 'tags' => array('Alibaba', 'Agentic AI', 'Best Chinese Model')),
        array('title' => 'Mistral Large 3', 'description' => 'Europe\'s leading open-source model, famous for ultra-high inference efficiency and excellent multilingual support.', 'url' => 'https://mistral.ai', 'icon' => '🌬️', 'category' => 'open_source', 'tags' => array('Mistral', 'High Efficiency', 'Multilingual')),
        array('title' => '01-Yi-Large-V2', 'description' => 'Enterprise-focused long-text model by 01.AI, optimized for reading comprehension and financial auditing scenarios.', 'url' => 'https://www.lingyiwanwu.com', 'icon' => '壹', 'category' => 'open_source', 'tags' => array('Enterprise-Grade', 'Long Text')),
        array('title' => 'CodeQwen 2.0', 'description' => 'Professional coding large model supporting 92 programming languages with high accuracy in full-stack development.', 'url' => 'https://github.com/QwenLM/CodeQwen', 'icon' => '💻', 'category' => 'open_source', 'tags' => array('Coding-Specific', 'Open Source')),
        array('title' => 'InternLM-3', 'description' => 'Latest generation by Shanghai AI Laboratory, focused on mathematical reasoning and scientific research with massive professional knowledge bases.', 'url' => 'internlm.shlab.org.cn', 'icon' => '🏫', 'category' => 'open_source', 'tags' => array('AI Lab', 'Scientific Reasoning')),

        // AI Art
        array('title' => 'Midjourney', 'description' => 'Leading AI image generation tool renowned for artistic styles and high-quality visuals.', 'url' => 'https://www.midjourney.com', 'icon' => '🎨', 'category' => 'image', 'tags' => array('Art Generation', 'Digital Art'), 'hot' => true),
        array('title' => 'DALL·E', 'description' => 'OpenAI text-to-image model that creates realistic visuals from textual descriptions.', 'url' => 'https://openai.com/dall-e-3', 'icon' => '🖼️', 'category' => 'image', 'tags' => array('OpenAI', 'Text-to-Image')),
        array('title' => 'Stable Diffusion', 'description' => 'Open-source text-to-image model supporting local deployment and advanced customization.', 'url' => 'https://stability.ai', 'icon' => '🎭', 'category' => 'image', 'tags' => array('Open Source', 'Text-to-Image')),
        array('title' => 'Dreamina AI', 'description' => 'ByteDance AI art platform with text-to-image, image-to-image and diverse creation modes.', 'url' => 'https://jimeng.jianying.com', 'icon' => '💭', 'category' => 'image', 'tags' => array('ByteDance', 'AI Creation')),
        array('title' => 'Adobe Firefly', 'description' => 'Adobe AI image generator deeply integrated with Photoshop workflows.', 'url' => 'https://firefly.adobe.com', 'icon' => '🔥', 'category' => 'image', 'tags' => array('Adobe', 'Design')),
        array('title' => 'Leonardo.ai', 'description' => 'Professional AI game asset platform for high-quality images and animation generation.', 'url' => 'https://leonardo.ai', 'icon' => '🎮', 'category' => 'image', 'tags' => array('Game Assets', 'Visual Design')),
        array('title' => 'Ideogram', 'description' => 'Specialized AI tool for typography and text-in-image generation.', 'url' => 'https://ideogram.ai', 'icon' => '✍️', 'category' => 'image', 'tags' => array('Typography', 'Graphic Design')),
        array('title' => 'Flux', 'description' => 'High-quality open-source image model developed by Black Forest Labs.', 'url' => 'https://flux.ai', 'icon' => '🌊', 'category' => 'image', 'tags' => array('Open Source', 'High Quality')),
        array('title' => 'Midjourney Niji', 'description' => 'Dedicated anime & illustration style AI art model.', 'url' => 'https://docs.midjourney.com/docs/niji', 'icon' => '🌸', 'category' => 'image', 'tags' => array('Anime', 'Illustration')),
        array('title' => 'Canva AI Generate', 'description' => 'Built-in AI image generator in Canva for one-click design asset creation.', 'url' => 'https://www.canva.com', 'icon' => '🎯', 'category' => 'image', 'tags' => array('Design', 'Templates')),
        array('title' => 'Tongyi Wanxiang', 'description' => 'Alibaba Cloud AI painting tool supporting multiple artistic styles.', 'url' => 'https://tongyi.aliyun.com/wanxiang', 'icon' => '🎪', 'category' => 'image', 'tags' => array('Alibaba', 'AI Art')),
        
        // AI Video
        array('title' => 'Sora', 'description' => 'OpenAI text-to-video model capable of generating high-definition short videos.', 'url' => 'https://sora.com', 'icon' => '🎬', 'category' => 'video', 'tags' => array('OpenAI', 'Text-to-Video'), 'hot' => true),
        array('title' => 'Runway', 'description' => 'Leading AI video editing & generation platform with rich creative AI tools.', 'url' => 'https://runwayml.com', 'icon' => '🎥', 'category' => 'video', 'tags' => array('Video Editing', 'Creative Tools')),
        array('title' => 'Pika', 'description' => 'Fast AI video platform supporting text/image-to-video conversion.', 'url' => 'https://pika.art', 'icon' => '⚡', 'category' => 'video', 'tags' => array('Text-to-Video', 'Image-to-Video')),
        array('title' => 'Kling AI', 'description' => 'High-quality AI video generator developed by Kuaishou.', 'url' => 'https://klingai.kuaishou.com', 'icon' => '🎞️', 'category' => 'video', 'tags' => array('Kuaishou', 'Video Generation')),
        array('title' => 'Luma Dream Machine', 'description' => 'Premium AI video generator for text and image-driven video creation.', 'url' => 'https://dreammachine.lumalabs.ai', 'icon' => '💫', 'category' => 'video', 'tags' => array('Video Generation', 'High Quality')),
        array('title' => 'HeyGen', 'description' => 'AI digital human video platform for realistic AI avatar production.', 'url' => 'https://heygen.com', 'icon' => '👤', 'category' => 'video', 'tags' => array('Digital Human', 'AI Host')),
        array('title' => 'Synthesia', 'description' => 'Professional AI video maker with multilingual virtual avatars.', 'url' => 'https://synthesia.io', 'icon' => '🌐', 'category' => 'video', 'tags' => array('Multilingual', 'Video Production')),
        array('title' => 'CapCut', 'description' => 'Powerful AI video editor developed by ByteDance.', 'url' => 'https://www.capcut.com', 'icon' => '✂️', 'category' => 'video', 'tags' => array('ByteDance', 'Video Editing')),
        array('title' => 'Jianying', 'description' => 'Intelligent video editing tool by ByteDance with full AI feature integration.', 'url' => 'https://www.jianying.com', 'icon' => '🎚️', 'category' => 'video', 'tags' => array('ByteDance', 'Video Cutting')),
        array('title' => 'Tencent Zhiying', 'description' => 'Tencent AI video creation platform with digital human and editing functions.', 'url' => 'https://zenvideo.qq.com', 'icon' => '🎬', 'category' => 'video', 'tags' => array('Tencent', 'AI Video')),
        
        // AI Audio
        array('title' => 'Suno', 'description' => 'AI music generation platform that creates complete songs from text prompts.', 'url' => 'https://suno.com', 'icon' => '🎵', 'category' => 'audio', 'tags' => array('Music', 'Song Generation'), 'hot' => true),
        array('title' => 'Udio', 'description' => 'Known as "Sora for music", delivering emotional and high-fidelity AI music.', 'url' => 'https://www.udio.com', 'icon' => '🎶', 'category' => 'audio', 'tags' => array('Music Generation', 'High-Fidelity'), 'hot' => true),
        array('title' => 'ElevenLabs', 'description' => 'Advanced AI voice synthesis with ultra-realistic voice cloning and multilingual dubbing.', 'url' => 'https://elevenlabs.io', 'icon' => '🔊', 'category' => 'audio', 'tags' => array('TTS', 'Voice Dubbing')),
        array('title' => 'Mureka', 'description' => 'Domestic AI music platform supporting Chinese & English song creation.', 'url' => 'https://mureka.com', 'icon' => '🎶', 'category' => 'audio', 'tags' => array('Music Creation', 'Chinese AI')),
        array('title' => 'Lovo AI', 'description' => 'Top-tier AI voiceover platform with 500+ human-like voices.', 'url' => 'https://lovo.ai', 'icon' => '🎙️', 'category' => 'audio', 'tags' => array('Dubbing', 'Multilingual TTS')),
        array('title' => 'iFlytek Voice', 'description' => 'Professional AI speech synthesis & dubbing service by iFlytek.', 'url' => 'https://zuo.sheng.xunfei.com', 'icon' => '🗣️', 'category' => 'audio', 'tags' => array('iFlytek', 'Speech AI')),
        array('title' => 'Azure Speech', 'description' => 'Microsoft Azure AI speech service with multilingual synthesis and custom voices.', 'url' => 'https://azure.microsoft.com/services/cognitive-services/speech-services', 'icon' => '🔵', 'category' => 'audio', 'tags' => array('Microsoft', 'TTS')),
        array('title' => 'NaturalReader', 'description' => 'AI text-to-speech tool for document and webpage reading.', 'url' => 'www.naturalreaders.com', 'icon' => '📖', 'category' => 'audio', 'tags' => array('Text Reading', 'Document TTS')),
        array('title' => 'Speechify', 'description' => 'AI reading assistant with multi-language support and adjustable playback speed.', 'url' => 'https://speechify.com', 'icon' => '📚', 'category' => 'audio', 'tags' => array('TTS', 'Learning Tool')),

        // AI 3D / Modeling
        array('title' => 'Luma Genie', 'description' => 'Text-to-3D tool by Luma AI for high-quality 3D model generation with multi-format export.', 'url' => 'https://lumalabs.ai/genie', 'icon' => '🧊', 'category' => '3d', 'tags' => array('3D Modeling', 'Text-to-3D'), 'hot' => true),
        array('title' => 'Meshy', 'description' => 'Next-gen AI 3D generator for fast mesh creation from text or images.', 'url' => 'https://www.meshy.ai', 'icon' => '🕸️', 'category' => '3d', 'tags' => array('Game Dev', '3D Modeling')),
        array('title' => 'Tripo AI', 'description' => 'High-precision 3D AI platform for instant production-ready 3D assets.', 'url' => 'www.tripoai.com', 'icon' => '📐', 'category' => '3d', 'tags' => array('High Precision', 'Industrial 3D')),
        array('title' => 'CSM AI', 'description' => 'Fast 2D-to-3D conversion from images/videos with rigging and export support.', 'url' => 'https://csm.ai', 'icon' => '🎬', 'category' => '3d', 'tags' => array('2D to 3D', 'Animation')),
        array('title' => 'Kaedim', 'description' => 'AI-powered 2D-to-3D tool designed for game and film industries.', 'url' => 'https://www.kaedim3d.com', 'icon' => '🎲', 'category' => '3d', 'tags' => array('Game Industry', '2D to 3D')),
        array('title' => 'Sloyd', 'description' => 'AI 3D asset generator providing ready-to-use models for game developers.', 'url' => 'https://sloyd.ai', 'icon' => '🎮', 'category' => '3d', 'tags' => array('Game Assets', 'Auto Generation')),

        // AI Coding
        array('title' => 'GitHub Copilot', 'description' => 'AI coding assistant by GitHub & OpenAI for intelligent auto-completion and code generation.', 'url' => 'https://github.com/features/copilot', 'icon' => '👨‍💻', 'category' => 'code', 'tags' => array('Coding', 'GitHub'), 'hot' => true),
        array('title' => 'Cursor', 'description' => 'AI-native code editor with built-in intelligent generation and refactoring.', 'url' => 'https://cursor.sh', 'icon' => '⌨️', 'category' => 'code', 'tags' => array('Code Editor', 'AI Coding'), 'hot' => true),
        array('title' => 'Lovable', 'description' => 'AI full-stack platform to build complete web apps from natural language prompts.', 'url' => 'https://lovable.dev', 'icon' => '💜', 'category' => 'code', 'tags' => array('Full Stack', 'Low Code'), 'hot' => true),
        array('title' => 'v0.dev', 'description' => 'Vercel AI UI generator for fast React component creation via text prompts.', 'url' => 'https://v0.dev', 'icon' => '🔧', 'category' => 'code', 'tags' => array('Frontend', 'UI Generation')),
        array('title' => 'Replit', 'description' => 'Online AI IDE for writing, running and deploying code across languages.', 'url' => 'https://replit.com', 'icon' => '💻', 'category' => 'code', 'tags' => array('Online IDE', 'Deployment')),
        array('title' => 'Codeium', 'description' => 'Free AI code completion tool supporting mainstream programming languages.', 'url' => 'https://codeium.com', 'icon' => '⚡', 'category' => 'code', 'tags' => array('Free Tool', 'Code Completion')),
        array('title' => 'Tabnine', 'description' => 'AI developer tool for code completion and smart refactoring suggestions.', 'url' => 'https://tabnine.com', 'icon' => '🔮', 'category' => 'code', 'tags' => array('Auto Complete', 'Code Refactor')),
        array('title' => 'Amazon CodeWhisperer', 'description' => 'AWS AI coding assistant for code generation and security scanning.', 'url' => 'https://aws.amazon.com/codewhisperer', 'icon' => '📦', 'category' => 'code', 'tags' => array('AWS', 'Code Security')),
        array('title' => 'Cody', 'description' => 'Sourcegraph AI coding assistant for code search and code understanding.', 'url' => 'https://sourcegraph.com/cody', 'icon' => '🦄', 'category' => 'code', 'tags' => array('Code Search', 'Code Analysis')),
        array('title' => 'JetBrains AI', 'description' => 'Built-in AI assistant for JetBrains IDEs to boost development efficiency.', 'url' => 'https://jb.gg/ai', 'icon' => '🚀', 'category' => 'code', 'tags' => array('IDE', 'Developer Tools')),
        array('title' => 'Devin', 'description' => 'AI software engineer by Cognition capable of handling complex programming tasks independently.', 'url' => 'https://cognition.ai', 'icon' => '🤖', 'category' => 'code', 'tags' => array('AI Engineer', 'Automated Dev')),
        array('title' => 'Bolt.new', 'description' => 'StackBlitz AI full-stack tool for instant in-browser development & deployment.', 'url' => 'https://bolt.new', 'icon' => '⚡', 'category' => 'code', 'tags' => array('Full Stack', 'Browser IDE')),
        
        // AI Writing
        array('title' => 'Notion AI', 'description' => 'Native Notion AI assistant for document generation, rewriting and summarization.', 'url' => 'https://www.notion.so/product/ai', 'icon' => '📄', 'category' => 'writing', 'tags' => array('Docs', 'Team Collaboration')),
        array('title' => 'Jasper', 'description' => 'Professional AI copywriting tool for ads, blogs, emails and marketing content.', 'url' => 'www.jasper.ai', 'icon' => '✍️', 'category' => 'writing', 'tags' => array('Marketing', 'Copywriting')),
        array('title' => 'Copy.ai', 'description' => 'Fast AI copy generator for marketing, social media and business emails.', 'url' => 'www.copy.ai', 'icon' => '📋', 'category' => 'writing', 'tags' => array('Content Writing', 'Marketing')),
        array('title' => 'Writesonic', 'description' => 'AI writing assistant for articles, ads and SEO optimization.', 'url' => 'writesonic.com', 'icon' => '✏️', 'category' => 'writing', 'tags' => array('SEO', 'Article Writing')),
        array('title' => 'Claude Writing', 'description' => 'High-quality content creation and writing assistance powered by Claude.', 'url' => 'https://claude.ai', 'icon' => '🧠', 'category' => 'writing', 'tags' => array('AI Assistant', 'Content Writing')),
        array('title' => 'WritingCat AI', 'description' => 'Domestic AI writing tool for grammar correction and content polishing.', 'url' => 'https://xiezuocat.com', 'icon' => '🐱', 'category' => 'writing', 'tags' => array('Chinese Writing', 'Proofreading')),
        array('title' => 'iFlytek Writing', 'description' => 'AI content creation platform by iFlytek for multi-style writing.', 'url' => 'writing.xunfei.cn', 'icon' => '✍️', 'category' => 'writing', 'tags' => array('iFlytek', 'Content Creation')),
        array('title' => 'Biling AI', 'description' => 'Multi-scenario writing tool for papers, reports and official documents.', 'url' => 'ibiling.cn', 'icon' => '📝', 'category' => 'writing', 'tags' => array('Document Writing', 'Official Docs')),
        array('title' => 'Grammarly', 'description' => 'Worldwide popular English writing assistant for grammar check and style optimization.', 'url' => 'www.grammarly.com', 'icon' => '🔤', 'category' => 'writing', 'tags' => array('English Writing', 'Grammar Check')),
        array('title' => 'Jenni AI', 'description' => 'Academic AI assistant for papers, literature reviews and research reports.', 'url' => 'jenni.ai', 'icon' => '🎓', 'category' => 'writing', 'tags' => array('Academic Writing', 'Research')),
        
        // AI Search
        array('title' => 'Perplexity', 'description' => 'AI-powered intelligent search engine with cited and accurate answers.', 'url' => 'https://www.perplexity.ai', 'icon' => '🔎', 'category' => 'search', 'tags' => array('AI Search', 'Q&A Engine'), 'hot' => true),
        array('title' => 'Phind', 'description' => 'Developer-focused AI search engine for precise technical solutions.', 'url' => 'www.phind.com', 'icon' => '🔬', 'category' => 'search', 'tags' => array('Tech Search', 'Dev Tools')),
        array('title' => 'Tiangong AI', 'description' => 'AI search engine by Kunlun Tech for intelligent Q&A and information retrieval.', 'url' => 'www.tiangong.cn', 'icon' => '🌐', 'category' => 'search', 'tags' => array('Chinese Search', 'AI Search')),
        array('title' => 'Kimi Explore', 'description' => 'Deep search version of Kimi with multi-round reasoning and web retrieval.', 'url' => 'kimi.moonshot.cn', 'icon' => '🔭', 'category' => 'search', 'tags' => array('Deep Search', 'Reasoning')),
        array('title' => 'Metaso AI Search', 'description' => 'Ad-free AI search engine providing structured results.', 'url' => 'metaso.cn', 'icon' => '🔍', 'category' => 'search', 'tags' => array('Ad-Free', 'Chinese Search')),
        array('title' => 'Genspark', 'description' => 'Next-gen AI search engine generating structured encyclopedia-style answers.', 'url' => 'www.genspark.ai', 'icon' => '🔥', 'category' => 'search', 'tags' => array('AI Search Engine', 'AI Aggregator'), 'hot' => true),
        array('title' => 'Quark AI Search', 'description' => 'Alibaba AI search function for intelligent content summarization.', 'url' => 'www.quark.cn', 'icon' => '🌟', 'category' => 'search', 'tags' => array('Alibaba', 'Browser AI')),
        array('title' => '360 AI Search', 'description' => 'AI search engine by 360 with intelligent webpage analysis.', 'url' => 'ai.so.com', 'icon' => '🔒', 'category' => 'search', 'tags' => array('Security Search', 'AI Analysis')),
        array('title' => 'Consensus', 'description' => 'Academic search AI for fast paper retrieval and research reference.', 'url' => 'consensus.ai', 'icon' => '📚', 'category' => 'search', 'tags' => array('Academic Search', 'Papers')),
        array('title' => 'You.com', 'description' => 'Personalized AI search engine with custom experience.', 'url' => 'you.com', 'icon' => '💬', 'category' => 'search', 'tags' => array('Personalized Search', 'AI Engine')),
        
        // AI Tools / Websites
        array('title' => 'Canva AI', 'description' => 'All-in-one AI design platform for posters, PPT, videos and visual content.', 'url' => 'www.canva.com', 'icon' => '🎯', 'category' => 'tool', 'tags' => array('Design Tools', 'Templates')),
        array('title' => 'Gamma', 'description' => 'AI presentation maker for fast professional slides and documents.', 'url' => 'gamma.app', 'icon' => '📊', 'category' => 'tool', 'tags' => array('PPT Maker', 'Presentations')),
        array('title' => 'Remove.bg', 'description' => 'AI background remover with one-click cutout and batch processing.', 'url' => 'www.remove.bg', 'icon' => '✂️', 'category' => 'tool', 'tags' => array('Background Remove', 'Image Tools')),
        array('title' => 'Dify', 'description' => 'Open-source LLM application platform for building and deploying AI services.', 'url' => 'dify.ai', 'icon' => '🛠️', 'category' => 'tool', 'tags' => array('AI Development', 'Open Source')),
        array('title' => 'ChatPDF', 'description' => 'AI document assistant for intelligent dialogue with PDF files.', 'url' => 'chatpdf.com', 'icon' => '📑', 'category' => 'tool', 'tags' => array('PDF Tool', 'Document AI')),
        array('title' => 'Notion', 'description' => 'AI-powered collaborative workspace for notes, docs and knowledge management.', 'url' => 'www.notion.so', 'icon' => '📝', 'category' => 'tool', 'tags' => array('Collaboration', 'Knowledge Base')),
        array('title' => 'Taskade', 'description' => 'AI-driven task management and team collaboration platform.', 'url' => 'www.taskade.com', 'icon' => '📋', 'category' => 'tool', 'tags' => array('Task Management', 'Teamwork')),
        array('title' => 'Beautiful.ai', 'description' => 'Smart AI presentation tool with automatic professional design layout.', 'url' => 'www.beautiful.ai', 'icon' => '✨', 'category' => 'tool', 'tags' => array('Slide Design', 'Presentations')),
        array('title' => 'Tome', 'description' => 'AI storytelling presentation tool for narrative-style slides.', 'url' => 'tome.net', 'icon' => '📖', 'category' => 'tool', 'tags' => array('Storytelling', 'Slides')),
        array('title' => 'MindMeister', 'description' => 'AI mind mapping tool for automatic idea generation and expansion.', 'url' => 'www.mindmeister.com', 'icon' => '🧠', 'category' => 'tool', 'tags' => array('Mind Map', 'Brainstorming')),
        array('title' => 'Warp', 'description' => 'Modern AI terminal with smart command completion and error repair.', 'url' => 'www.warp.dev', 'icon' => '💻', 'category' => 'tool', 'tags' => array('Terminal', 'Dev Tools')),

        // Model Communities
        array('title' => 'Hugging Face', 'description' => 'World’s largest open-source AI model library, dataset hub and demo platform.', 'url' => 'huggingface.co', 'icon' => '🤗', 'category' => 'community', 'tags' => array('Open Source', 'Model Hub', 'Datasets'), 'hot' => true),
        array('title' => 'Civitai', 'description' => 'Most popular Stable Diffusion community with massive LoRA & checkpoint resources.', 'url' => 'civitai.com', 'icon' => '🖼️', 'category' => 'community', 'tags' => array('SD Models', 'AI Art Community', 'Open Source'), 'hot' => true),
        array('title' => 'ModelScope', 'description' => 'Alibaba AI open community gathering mainstream domestic models and datasets.', 'url' => 'modelscope.cn', 'icon' => '🧪', 'category' => 'community', 'tags' => array('Alibaba', 'Chinese AI', 'Open Source')),
        array('title' => 'Liblib AI', 'description' => 'Leading domestic AI art community with original art models and online generation.', 'url' => 'www.liblib.art', 'icon' => '🎨', 'category' => 'community', 'tags' => array('Chinese Community', 'Art Models')),
        array('title' => 'Kaggle', 'description' => 'Google’s global data science competition platform with massive datasets & notebooks.', 'url' => 'www.kaggle.com', 'icon' => '📊', 'category' => 'community', 'tags' => array('Data Science', 'Datasets')),
        array('title' => 'Papers with Code', 'description' => 'Paper & code tracking platform for latest AI research and open-source implementations.', 'url' => 'paperswithcode.com', 'icon' => '📄', 'category' => 'community', 'tags' => array('AI Research', 'Open Code')),
        array('title' => 'Replicate', 'description' => 'Cloud platform to run open AI models instantly without local setup.', 'url' => 'replicate.com', 'icon' => '🔄', 'category' => 'community', 'tags' => array('Cloud Inference', 'One-Click Run')),

        // Office Productivity
        array('title' => 'Monica', 'description' => 'All-round AI browser extension for summary, sidebar chat and webpage translation.', 'url' => 'monica.im', 'icon' => '🦋', 'category' => 'productivity', 'tags' => array('Browser Assistant', 'Multi-Model'), 'hot' => true),
        array('title' => 'Otter.ai', 'description' => 'Intelligent meeting assistant for real-time speech-to-text and meeting summaries.', 'url' => 'otter.ai', 'icon' => '🦦', 'category' => 'productivity', 'tags' => array('Meeting AI', 'Work Efficiency')),
        array('title' => 'Harvey AI', 'description' => 'Legal AI assistant designed for lawyers & judges with document analysis and case search.', 'url' => 'www.harvey.ai', 'icon' => '⚖️', 'category' => 'productivity', 'tags' => array('Legal AI', 'Professional Tools')),
        array('title' => 'Gamma', 'description' => 'AI-powered presentation & document generator for professional content.', 'url' => 'gamma.app', 'icon' => '📊', 'category' => 'productivity', 'tags' => array('PPT Maker', 'Docs')),
        array('title' => 'TLDV', 'description' => 'AI meeting recorder & summarizer to extract key points and action items.', 'url' => 'tldv.io', 'icon' => '📹', 'category' => 'productivity', 'tags' => array('Meeting Recorder', 'Summary AI')),
        array('title' => 'Mem', 'description' => 'AI note-taking tool for automatic knowledge organization & connection.', 'url' => 'get.mem', 'icon' => '🧩', 'category' => 'productivity', 'tags' => array('Notes', 'Knowledge Management')),
        array('title' => 'Reclaim AI', 'description' => 'AI schedule manager for smart meeting arrangement and focus time planning.', 'url' => 'reclaim.ai', 'icon' => '📅', 'category' => 'productivity', 'tags' => array('Scheduling', 'Time Management')),
        array('title' => 'Feishu AI', 'description' => 'Built-in Feishu AI for summary, translation and automatic meeting minutes.', 'url' => 'www.feishu.cn', 'icon' => '🐦', 'category' => 'productivity', 'tags' => array('Feishu', 'Team Collaboration')),

        // E-commerce Marketing
        array('title' => 'Flair.ai', 'description' => 'Brand AI photo studio to generate commercial product visuals in one click.', 'url' => 'flair.ai', 'icon' => '🧴', 'category' => 'marketing', 'tags' => array('E-commerce', 'Product Photography'), 'hot' => true),
        array('title' => 'Namelix', 'description' => 'AI brand name generator with custom logo and brand visual design.', 'url' => 'namelix.com', 'icon' => '🏷️', 'category' => 'marketing', 'tags' => array('Branding', 'Logo Design')),
        array('title' => 'AdCreative.ai', 'description' => 'AI ad creator for high-CTR banners and social media marketing assets.', 'url' => 'www.adcreative.ai', 'icon' => '📈', 'category' => 'marketing', 'tags' => array('Advertising', 'Marketing Assets')),
        array('title' => 'Copy.ai', 'description' => 'AI marketing copy platform for ads, social posts and product descriptions.', 'url' => 'www.copy.ai', 'icon' => '📋', 'category' => 'marketing', 'tags' => array('Marketing Copy', 'Promotion')),
        array('title' => 'Pebblely', 'description' => 'AI product image generator for e-commerce scene visualization.', 'url' => 'pebblely.com', 'icon' => '🛍️', 'category' => 'marketing', 'tags' => array('Product Images', 'E-commerce AI')),
        array('title' => 'Mokker AI', 'description' => 'AI product photography tool for instant background & scene replacement.', 'url' => 'mokker.ai', 'icon' => '📸', 'category' => 'marketing', 'tags' => array('Product Shots', 'Background Changer')),
        array('title' => 'Jasper Art', 'description' => 'Brand visual AI generator for consistent marketing artwork.', 'url' => 'www.jasper.ai/art', 'icon' => '🎨', 'category' => 'marketing', 'tags' => array('Brand Design', 'Marketing Visuals')),

        // Local Deployment
        array('title' => 'DH Resource', 'description' => 'Leading AI tech resource platform focusing on local LLM deployment, tutorials, software and optimization guides.', 'url' => 'www.dhzyw.com', 'icon' => '🌊', 'category' => 'local', 'tags' => array('Local Deployment', 'AI Resources')),
        array('title' => 'Ollama', 'description' => 'Minimal local LLM runtime for one-click deployment of Llama, Gemma and open models.', 'url' => 'ollama.com', 'icon' => '🦙', 'category' => 'local', 'tags' => array('Local AI', 'Open Source', 'Multi-Platform'), 'hot' => true),
        array('title' => 'LM Studio', 'description' => 'Graphical local model manager and inference tool for hardware testing.', 'url' => 'lmstudio.ai', 'icon' => '💻', 'category' => 'local', 'tags' => array('Local Inference', 'GUI Tool')),
        array('title' => 'AnythingLLM', 'description' => 'All-in-one private RAG solution to turn local documents into knowledge bases.', 'url' => 'useanything.com', 'icon' => '📂', 'category' => 'local', 'tags' => array('RAG', 'Knowledge Base', 'Private AI')),
        array('title' => 'OpenClaw', 'description' => 'Powerful open-source AI terminal assistant with multi-model switching & local deployment.', 'url' => 'https://github.com/idootop/openclaw', 'icon' => '🦞', 'category' => 'local', 'tags' => array('Open Source', 'Local AI'), 'hot' => true),
        array('title' => 'Docker Ollama', 'description' => 'One-click Docker deployment for Ollama + WebUI to build local AI services quickly.', 'url' => 'https://github.com/valiantlynx/ollama-docker', 'icon' => '🐳', 'category' => 'local', 'tags' => array('Docker', 'Containerization')),
        array('title' => 'LocalAI', 'description' => 'OpenAI API-compatible local inference service for seamless offline replacement.', 'url' => 'localai.io', 'icon' => '🔌', 'category' => 'local', 'tags' => array('API Compatible', 'Offline Inference')),
        array('title' => 'text-generation-webui', 'description' => 'Open-source text generation WebUI supporting multiple model formats and LoRA fine-tuning.', 'url' => 'https://github.com/oobabooga/text-generation-webui', 'icon' => '🖥️', 'category' => 'local', 'tags' => array('WebUI', 'Model Fine-Tuning')),
    );
    
    $order = 1;
    foreach ($sample_tools as $tool) {
        $post_id = wp_insert_post(array(
            'post_type' => 'ai_tool',
            'post_title' => $tool['title'],
            'post_content' => $tool['description'],
            'post_status' => 'publish',
            'post_excerpt' => $tool['description']
        ));
        
        if (!is_wp_error($post_id)) {
            update_post_meta($post_id, 'tool_url', $tool['url']);
            update_post_meta($post_id, 'tool_icon', $tool['icon']);
            update_post_meta($post_id, 'tool_hot', !empty($tool['hot']));
            update_post_meta($post_id, 'tool_order', $order++);
            
            // Set Category
            $cat_slug = $tool['category'];
            if (isset($cat_ids[$cat_slug])) {
                wp_set_object_terms($post_id, $cat_ids[$cat_slug], 'ai_category');
            }
            
            // Set Tags
            foreach ($tool['tags'] as $tag_name) {
                $tag = wp_insert_term($tag_name, 'ai_tag');
                if (!is_wp_error($tag)) {
                    wp_set_object_terms($post_id, $tag['term_id'], 'ai_tag', true);
                } else {
                    $existing = get_term_by('name', $tag_name, 'ai_tag');
                    if ($existing) {
                        wp_set_object_terms($post_id, $existing->term_id, 'ai_tag', true);
                    }
                }
            }
        }
    }
}

/**
 * Create sample data & flush rewrite rules on theme activation
 */
function ai_navigator_activate() {
    ai_navigator_create_sample_data();
    flush_rewrite_rules();
}
add_action('after_switch_theme', 'ai_navigator_activate');

/**
 * Flush rewrite rules on theme deactivation
 */
function ai_navigator_deactivate() {
    flush_rewrite_rules();
}
add_action('switch_theme', 'ai_navigator_deactivate');

/**
 * Admin Initialization Fallback
 * Ensure sample data is created if activation hook fails
 * Will not re-import if data is manually cleared
 */
function ai_navigator_ensure_sample_data() {
    // Only run in backend
    if (!is_admin()) return;
    
    // Stop auto import if user cleared data manually
    if (get_option('dh_nav_data_cleared')) return;
    
    // Check existing posts
    $existing = get_posts(array('post_type' => 'ai_tool', 'posts_per_page' => 1, 'post_status' => 'publish'));
    if (empty($existing)) {
        ai_navigator_create_sample_data();
        flush_rewrite_rules();
    }
}
add_action('admin_init', 'ai_navigator_ensure_sample_data');